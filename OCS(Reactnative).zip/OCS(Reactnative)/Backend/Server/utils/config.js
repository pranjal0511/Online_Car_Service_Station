module.exports = {
  SECRET: 'car_service_secret',
  SALT_ROUND: 10
}
